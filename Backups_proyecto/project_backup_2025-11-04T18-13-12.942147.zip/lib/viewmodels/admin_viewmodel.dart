import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../services/mongo_service.dart';

/// ViewModel para gestionar las operaciones administrativas
class AdminViewModel extends ChangeNotifier {
  final MongoService _mongoService = MongoService();

  List<User> _users = [];
  User? _selectedUser;
  bool _isLoading = false;
  String? _errorMessage;
  String? _successMessage;

  User? _editingUser;
  bool _showEditForm = false;
  bool _showDeleteConfirmation = false;
  User? _userToDelete;

  List<User> get users => _users;
  User? get selectedUser => _selectedUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get successMessage => _successMessage;
  User? get editingUser => _editingUser;
  bool get showEditForm => _showEditForm;
  bool get showDeleteConfirmation => _showDeleteConfirmation;
  User? get userToDelete => _userToDelete;

  /// Cargar la lista completa de usuarios
  Future<void> loadUsers() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _users = await _mongoService.getAllUsers();
      print('✅ Usuarios cargados: ${_users.length}');
    } catch (e) {
      _errorMessage = 'Error al cargar usuarios: $e';
      print('❌ Error: $_errorMessage');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Seleccionar un usuario
  void selectUser(User user) {
    _selectedUser = user;
    _editingUser = user;
    notifyListeners();
  }

  /// Abrir el formulario de edición
  void openEditForm() {
    _showEditForm = true;
    notifyListeners();
  }

  /// Cerrar el formulario de edición
  void closeEditForm() {
    _showEditForm = false;
    _editingUser = null;
    notifyListeners();
  }

  /// Abrir el diálogo de confirmación de eliminación
  void openDeleteConfirmation(User user) {
    _userToDelete = user;
    _showDeleteConfirmation = true;
    notifyListeners();
  }

  /// Cerrar el diálogo de confirmación
  void closeDeleteConfirmation() {
    _showDeleteConfirmation = false;
    _userToDelete = null;
    notifyListeners();
  }

  /// Actualizar la información completa de un usuario
  Future<void> updateUser(User user) async {
    _isLoading = true;
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();

    try {
      final updates = <String, dynamic>{
        'Email': user.email,
        'Username': user.username,
        'Name': user.name,
        if (user.fullName != null) 'FullName': user.fullName,
        if (user.phone != null) 'Phone': user.phone,
        if (user.company != null) 'Company': user.company,
        if (user.address != null) 'Address': user.address,
        if (user.occupation != null) 'Occupation': user.occupation,
        if (user.profileImageUrl != null)
          'ProfileImageUrl': user.profileImageUrl,
        'Role': user.isAdmin ? 'admin' : 'user',
        'IsActive': user.isActive ?? true,
      };

      final success = await _mongoService.updateUser(user.id, updates);

      if (success) {
        _successMessage = 'Usuario actualizado correctamente';
        await loadUsers();
        closeEditForm();
      } else {
        _errorMessage = 'Error al actualizar usuario';
      }
    } catch (e) {
      _errorMessage = 'Error al actualizar usuario: $e';
      print('❌ Error: $_errorMessage');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Eliminar un usuario físicamente de la base de datos
  Future<void> deleteUser(User user) async {
    _isLoading = true;
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();

    try {
      // Eliminar físicamente el usuario
      final success = await _mongoService.deleteUser(user.id);

      if (success) {
        _successMessage = 'Usuario eliminado correctamente';
        await loadUsers();
        closeDeleteConfirmation();
      } else {
        _errorMessage =
            'Error al eliminar usuario: no se pudo completar la operación';
      }
    } catch (e) {
      _errorMessage = 'Error al eliminar usuario: $e';
      print('❌ Error: $_errorMessage');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Actualizar el rol de un usuario
  Future<void> updateUserRole(User user, {required bool isAdmin}) async {
    _isLoading = true;
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();

    try {
      final updates = {'Role': isAdmin ? 'admin' : 'user'};
      final success = await _mongoService.updateUser(user.id, updates);

      if (success) {
        _successMessage = isAdmin
            ? 'Usuario promovido a administrador'
            : 'Usuario convertido a usuario normal';
        await loadUsers();
      } else {
        _errorMessage = 'Error al actualizar el rol del usuario';
      }
    } catch (e) {
      _errorMessage = 'Error al actualizar el rol del usuario: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Actualizar el estado activo de un usuario
  Future<void> updateUserActiveStatus(
    User user, {
    required bool isActive,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();

    try {
      final updates = {'IsActive': isActive};
      final success = await _mongoService.updateUser(user.id, updates);

      if (success) {
        _successMessage = isActive
            ? 'Usuario activado correctamente'
            : 'Usuario desactivado correctamente';
        await loadUsers();
      } else {
        _errorMessage = 'Error al actualizar el estado del usuario';
      }
    } catch (e) {
      _errorMessage = 'Error al actualizar el estado del usuario: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Crear un nuevo usuario
  Future<void> createUser({
    required String username,
    required String name,
    required String email,
    required String password,
    bool isAdmin = false,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    _successMessage = null;
    notifyListeners();

    try {
      // Verificar si el usuario ya existe
      final userExists = await _mongoService.checkUserExists(email);
      if (userExists) {
        _errorMessage = 'Ya existe un usuario con ese email';
        _isLoading = false;
        notifyListeners();
        return;
      }

      // Crear el usuario
      await _mongoService.createUser(
        username: username,
        name: name,
        email: email,
        password: password,
      );

      // Si se especifica como admin, actualizar el rol
      if (isAdmin) {
        final newUser = await _mongoService.getUserByEmail(email);
        if (newUser != null) {
          await updateUserRole(newUser, isAdmin: true);
        }
      }

      _successMessage = 'Usuario creado correctamente';
      await loadUsers();
    } catch (e) {
      _errorMessage = 'Error al crear usuario: $e';
      print('❌ Error: $_errorMessage');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Limpiar mensajes
  void clearMessages() {
    Future.delayed(const Duration(seconds: 3), () {
      _errorMessage = null;
      _successMessage = null;
      notifyListeners();
    });
  }
}
